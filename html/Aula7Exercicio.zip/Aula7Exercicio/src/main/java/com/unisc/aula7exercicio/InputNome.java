/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.unisc.aula7exercicio;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "InputNome", urlPatterns = {"/input_nome"})
public class InputNome extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        // Assim que o servlet é chamado, renderiza o seu JSP
        request.getRequestDispatcher("/WEB-INF/input_nome.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // instancia a session para ser utilizada
        HttpSession session = request.getSession();
        // Busca atributo no forms que veio do jsp
        String nome = request.getParameter("nome");
        // Verifica se veio valores do forms
        if (nome != null && !nome.isEmpty()) {
            // Se vieram valores, adiciona estes na sessão
            session.setAttribute("nome", nome);
        }
        // No final, faz o redirect para a página 1
        response.sendRedirect("/Aula7Exercicio/page_1");
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
