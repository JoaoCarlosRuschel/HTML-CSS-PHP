/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.unisc.aula7exercicio;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author mateu
 */
@WebServlet(name = "Page1", urlPatterns = {"/page_1"})
public class Page1 extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // instancia a session para ser utilizada
        HttpSession session = request.getSession();
        // Busca atributo nome na sessão
        // Quando busca da sessão, ele vem como Object no java.
        Object user = session.getAttribute("nome");
        // Verifica se foi encontrado o nome na sessão
        if (user != null) {
            // Se foi encontrado, pode renderizar a página normalmente
            response.setContentType("text/html;charset=UTF-8");
            request.getRequestDispatcher("/WEB-INF/page1.jsp").forward(request, response);
        } else {
            // Senão redireciona para a página de input de nome novamente.
            response.sendRedirect("/Aula7Exercicio/input_nome");
        }

    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
